import Featured3Col from './3col';
import FeaturedCenter2By2 from './center_2x2';
import FeaturedOffset2By2Grid from './offset_2x2_grid';
import FeatureImageImage from './split_image';

export { FeatureImageImage, FeaturedCenter2By2, FeaturedOffset2By2Grid, Featured3Col };
