import TeamSection from './section';
import TeamShortParagraph from './short_paragraph';

export { TeamShortParagraph, TeamSection };

