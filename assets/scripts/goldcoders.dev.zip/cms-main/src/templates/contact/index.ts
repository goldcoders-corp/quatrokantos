import ContactCard from './card';

export { ContactCard };
