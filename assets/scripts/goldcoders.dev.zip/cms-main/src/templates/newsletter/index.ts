import NewsletterCustomBg from './custom_bg';
import NewsletterOnCard from './on_card';
import NewsletterSimpleStacked from './simple_stacked';

export { NewsletterSimpleStacked, NewsletterOnCard, NewsletterCustomBg };
