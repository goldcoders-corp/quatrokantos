import TestimonialSideBySide from './side_by_side';
import TestimonialSimpleCentered from './simple_centered';
import TesttimonialWithLargeAvatar from './with_large_avatar';

export { TestimonialSimpleCentered, TestimonialSideBySide, TesttimonialWithLargeAvatar };
