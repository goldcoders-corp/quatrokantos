import AppConfig from './config';
import MenuConfig from './menu';
import ParamConfig from './params';
export { AppConfig, MenuConfig, ParamConfig };
