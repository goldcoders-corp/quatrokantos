let InputTags: Array<string> = [
    "input",
    "textarea"
];

export default InputTags;