let WordSize: Array<string> = [
    "auto", "px", "full", "screen",
];

export default WordSize;