let FloatSize: Array<string> = ["0.5", "1.5", "2.5", "3.5"];

export default FloatSize;