let HTTPMETHODS: Array<string> = [
    "POST",
    "GET",
    "UPDATE",
    "DELETE"
];

export default HTTPMETHODS;