import BlogContent from './blog';
import ContactContent from './contact';
import FaqContent from './faq';
import LegalitiesContent from './legalities';
import ProductContent from './product';
export { BlogContent, ProductContent, FaqContent, ContactContent, LegalitiesContent };

