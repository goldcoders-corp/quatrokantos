# We Have 2 .ts file here

> cms.ts is for (local)

> main.ts is for (production)

Note: This Error on terminal is expected

```
[snowpack] [404] Not Found (/config.yml)
```

Since the config.yml contents is within cms.ts / main.ts
